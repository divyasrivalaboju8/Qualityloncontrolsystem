# Quality Log Control

## Description

This project captures logs from multiple APIs, stores them in designated log files, and provides a query interface for searching the logs. The logs are formatted in JSON, containing details such as timestamp, log level, log message, and source. The system is designed to be scalable, efficient, and user-friendly.

## Features Implemented

- Integration of multiple APIs for log generation.
- Standardized log formatting.
- Configuration for logging levels and file paths.
- Robust error handling mechanisms.
- CLI for querying logs.
- Filters for log level, log message, timestamp, and source.
- Efficient log search functionality.

## System Design

The system consists of two main components:
1. **Log Ingestor**: Handles the logging of messages from various APIs to designated files.
2. **Query Interface**: Provides a user-friendly interface for searching logs with various filters.

The log ingestor uses a standardized JSON format for logs and supports configuration through a file or environment variables. The query interface allows users to search logs based on log level, message content, timestamp, and source.

## How to Run the Project

1. **Setup the Environment**
   - Ensure Python is installed on your system.
   - Create and activate a virtual environment:
     ```sh
     python -m venv venv
     source venv/bin/activate  # On Windows use `venv\Scripts\activate`
     ```

2. **Install Dependencies**
   - Install necessary Python packages:
     ```sh
     pip install -r requirements.txt
     ```

3. **Run the Log Ingestor**
   - Run the log ingestor script to start logging:
     ```sh
     python log_ingestor.py
     ```

4. **Run the Query Interface**
   - Run the query interface script to search logs:
     ```sh
     python query_interface.py
     ```

5. **Sample Queries**
   - Modify and run the query script to test different filters.

## Identified Issues

- Ensure that log files are managed properly to prevent excessive disk usage.
- Implementing advanced features may require additional optimization for performance.


