
import logging
import json
from datetime import datetime

def setup_logging(config):
    for api, log_file in config['log_paths'].items():
        logger = logging.getLogger(api)
        handler = logging.FileHandler(log_file)
        formatter = logging.Formatter('%(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)

def log_message(api, level, message):
    logger = logging.getLogger(api)
    log_entry = {
        "level": level,
        "log_string": message,
        "timestamp": datetime.utcnow().isoformat(),
        "metadata": {
            "source": f"{api}.log"
        }
    }
    logger.info(json.dumps(log_entry))

if __name__ == "__main__":
    config = {
        "log_levels": ["info", "error", "success"],
        "log_paths": {
            "api1": "log1.log",
            "api2": "log2.log"
        }
    }

    setup_logging(config)
    log_message("api1", "error", "Inside the Search API")
    log_message("api2", "info", "Starting the service")
    log_message("api1", "success", "Service started successfully")
