import json
import glob

def search_logs(level=None, log_string=None, start_time=None, end_time=None, source=None):
    logs = []
    for log_file in glob.glob('log*.log'):
        with open(log_file, 'r') as file:
            for line in file:
                log_entry = json.loads(line)
                if level and log_entry['level'] != level:
                    continue
                if log_string and log_string not in log_entry['log_string']:
                    continue
                if start_time and log_entry['timestamp'] < start_time:
                    continue
                if end_time and log_entry['timestamp'] > end_time:
                    continue
                if source and log_entry['metadata']['source'] != source:
                    continue
                logs.append(log_entry)
    return logs

if __name__ == "__main__":
    results = search_logs(level="error", log_string="Search API", start_time="2023-09-10T00:00:00Z", end_time="2023-09-15T23:59:59Z")
    print(json.dumps(results, indent=4))
